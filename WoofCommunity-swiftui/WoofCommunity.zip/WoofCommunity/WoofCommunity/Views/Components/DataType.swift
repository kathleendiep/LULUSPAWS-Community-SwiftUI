

import Foundation

struct datatype : Identifiable {
    // name of the actual property
    var id : String
    var caption : String
    var geoLocation : String
    var ownerId : String
    var postId : String
    var username : String
    var profile : String
    var mediaUrl : String
}


//
//  SearchBar.swift
//  WoofCommunity
//
//  Created by Kathleen Diep on 7/27/22.
//

import SwiftUI

struct Search: View {

    var body: some View {
        ScrollView{
            VStack{
                Text("Search")
            }
        }
//       SearchBar(value)
    }
}



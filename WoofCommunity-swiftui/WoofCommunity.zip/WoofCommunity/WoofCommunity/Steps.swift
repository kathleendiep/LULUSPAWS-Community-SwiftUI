/*
 
 - move logout page elsewhere
 - add more fields to user
 - load data
 - profile
 
 
 
 STRETCH
 - how to add multiple pics
 - post
- make a homeview when session = nil
    - log in button
 
 
 Questions:
 - what do i do after a login.. How do i match the email to the profile or post?
 
 plan:
 1. have user login
 - SignInVM
 - Goes to storage
 
 2. model: make a profile
 - UserVM
 - Goes to collection users
 
 
 - username
 - name
 - pet name
 - humanProfilePic
 - dogPrfoilePic
 - email (but hidden)

 - uuid ?
 - bio
 - location (to do later)
 - [posts]
 - [pictures]
 
 3. model: make a post ?? - this is for later
 - uuid
 - picture
 - caption
 
 
 - how do I get storage
 */




/*
 GET
 
 
 
 - DELETE
 - add button
 */
